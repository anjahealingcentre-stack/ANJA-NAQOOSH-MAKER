package com.anja.naqoomaker

import android.os.Bundle
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF176B45)
private val PaleGreen = Color(0xFFEAF4EE)
private val Ink = Color(0xFF18372A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnjaApp() }
    }
}

@Composable
fun AnjaApp() {
    var page by remember { mutableStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = Color(0xFF4D8B68),
            background = Color(0xFFF8FBF8),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Color(0xFFF8FBF8),
                topBar = {
                    Column(
                        Modifier.fillMaxWidth().background(Green).padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("ANJA NAQOOSH MAKER", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("ادارہ انجاء ہیلنگ سینٹر", color = Color.White, fontSize = 14.sp)
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(selected = page == 0, onClick = { page = 0 },
                            icon = { Text("ا ب") }, label = { Text("ابجد حساب") })
                        NavigationBarItem(selected = page == 1, onClick = { page = 1 },
                            icon = { Text("▦") }, label = { Text("نقش ساز") })
                        NavigationBarItem(selected = page == 2, onClick = { page = 2 },
                            icon = { Text("؟") }, label = { Text("تعارف") })
                    }
                }
            ) { padding ->
                when (page) {
                    0 -> AbjadScreen(Modifier.padding(padding))
                    1 -> NaqshScreen(Modifier.padding(padding))
                    else -> AboutScreen(Modifier.padding(padding))
                }
            }
        }
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFD8E8DE)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

private val arabicAbjad = mapOf(
    'ا' to 1, 'آ' to 1, 'أ' to 1, 'إ' to 1, 'ء' to 1, 'ب' to 2, 'ج' to 3, 'د' to 4,
    'ه' to 5, 'ة' to 5, 'و' to 6, 'ؤ' to 6, 'ز' to 7, 'ح' to 8, 'ط' to 9,
    'ي' to 10, 'ى' to 10, 'ئ' to 10, 'ك' to 20, 'ل' to 30, 'م' to 40,
    'ن' to 50, 'س' to 60, 'ع' to 70, 'ف' to 80, 'ص' to 90,
    'ق' to 100, 'ر' to 200, 'ش' to 300, 'ت' to 400, 'ث' to 500,
    'خ' to 600, 'ذ' to 700, 'ض' to 800, 'ظ' to 900, 'غ' to 1000
)

// Urdu/Persian additional letters are mapped to their conventional base-letter values.
private val urduAbjad = arabicAbjad + mapOf(
    'ٹ' to 400, 'ڈ' to 4, 'ڑ' to 200, 'ں' to 50, 'ھ' to 5, 'ے' to 10,
    'پ' to 2, 'چ' to 3, 'ژ' to 7, 'گ' to 20
)
private val persianAbjad = arabicAbjad + mapOf('پ' to 2, 'چ' to 3, 'ژ' to 7, 'گ' to 20)

// User-supplied custom tables transcribed from the three reference screenshots.
private val shamsiAbjad = mapOf(
    'ا' to 1, 'ب' to 2, 'ج' to 5, 'د' to 8, 'ہ' to 900, 'ه' to 900, 'ھ' to 900, 'و' to 800,
    'ز' to 20, 'ح' to 6, 'ط' to 70, 'ی' to 1000, 'ي' to 1000, 'ک' to 400, 'ك' to 400,
    'ل' to 500, 'م' to 600, 'ن' to 700, 'س' to 30, 'ع' to 90, 'ف' to 200, 'ص' to 50,
    'ق' to 300, 'ر' to 10, 'ش' to 40, 'ت' to 3, 'ث' to 4, 'خ' to 7, 'ذ' to 9,
    'ض' to 60, 'ظ' to 80, 'غ' to 100, 'ة' to 3
)
private val tilismAbjad = mapOf(
    'ا' to 1848, 'ب' to 11088, 'ج' to 22176, 'د' to 36960, 'ہ' to 55440, 'ه' to 55440, 'ھ' to 55440, 'و' to 77616,
    'ز' to 103488, 'ح' to 133056, 'ط' to 166320, 'ی' to 203280, 'ي' to 203280,
    'ک' to 759528, 'ك' to 759528, 'ل' to 1685376, 'م' to 2980824, 'ن' to 4645872,
    'س' to 6680520, 'ع' to 9084768, 'ف' to 11858616, 'ص' to 15002064, 'ق' to 18515112,
    'ر' to 73956960, 'ش' to 166358808, 'ت' to 295720656, 'ث' to 462042504,
    'خ' to 665324352, 'ذ' to 905566200, 'ض' to 1182768048, 'ظ' to 1496929896,
    'غ' to 1848051744, 'ة' to 55440
)
private val malfoziAbjad = mapOf(
    'ا' to 111, 'ب' to 3, 'ج' to 53, 'د' to 35, 'ہ' to 6, 'ه' to 6, 'ھ' to 6, 'و' to 13,
    'ز' to 8, 'ح' to 9, 'ط' to 10, 'ی' to 11, 'ي' to 11, 'ک' to 101, 'ك' to 101,
    'ل' to 71, 'م' to 90, 'ن' to 106, 'س' to 120, 'ع' to 130, 'ف' to 81, 'ص' to 95,
    'ق' to 181, 'ر' to 201, 'ش' to 360, 'ت' to 401, 'ث' to 501, 'خ' to 601,
    'ذ' to 731, 'ض' to 805, 'ظ' to 901, 'غ' to 1060, 'ة' to 401
)

@Composable
fun AbjadScreen(modifier: Modifier = Modifier) {
    var input by remember { mutableStateOf("") }
    var table by remember { mutableStateOf("اردو") }
    var menuOpen by remember { mutableStateOf(false) }
    var selectedOrder by remember { mutableIntStateOf(0) }
    var generatedGrid by remember { mutableStateOf<List<List<Int>>?>(null) }
    var generatedLabel by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val values = when (table) {
        "عربی" -> arabicAbjad
        "فارسی" -> persianAbjad
        "ابجد شمسی" -> shamsiAbjad
        "ابجد طلسم" -> tilismAbjad
        "ابجد ملفوظی" -> malfoziAbjad
        else -> urduAbjad
    }
    val total = input.sumOf { values[it] ?: 0 }
    val known = input.filter { values.containsKey(it) }
    val unknown = input.filter { !values.containsKey(it) && !it.isWhitespace() }
    val breakdown = known.map { "$it = ${values[it]}" }

    val naqshTypes = listOf(
        3 to "نقش مثلث", 4 to "نقش مربع", 5 to "نقش مخمس",
        6 to "نقش مسدس", 7 to "نقش مسبع", 8 to "نقش مثمن",
        9 to "نقش متسع", 10 to "نقش معشر",
        11 to "نقش احد عشر", 12 to "نقش اثنا عشر"
    )

    Column(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Panel(if (table.startsWith("ابجد")) "$table کا حساب" else "ابجد کبیر کا حساب") {
            Text("ابجد کا جدول منتخب کریں:", color = Ink)
            Box {
                OutlinedButton(onClick = { menuOpen = true }) { Text("$table جدول  ▾") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    listOf("عربی", "اردو", "فارسی", "ابجد شمسی", "ابجد طلسم", "ابجد ملفوظی").forEach { name ->
                        DropdownMenuItem(text = { Text(name) }, onClick = {
                            table = name
                            menuOpen = false
                            generatedGrid = null
                            selectedOrder = 0
                        })
                    }
                }
            }
            OutlinedTextField(
                value = input, onValueChange = {
                    input = it
                    generatedGrid = null
                    selectedOrder = 0
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("مثلاً: محمد") },
                minLines = 2
            )
            Text("کل عدد: $total", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (breakdown.isNotEmpty()) Text(breakdown.joinToString("   "))
            if (unknown.isNotEmpty()) Text(
                "غیر شامل حروف: ${unknown.toSet().joinToString("، ")} — ان کی قدر اس جدول میں مقرر نہیں۔",
                color = Color(0xFF9A5B00), fontSize = 12.sp
            )
            Text(
                if (table in listOf("ابجد شمسی", "ابجد طلسم", "ابجد ملفوظی"))
                    "یہ جدول آپ کے فراہم کردہ اسکرین شاٹس سے نقل کیا گیا ہے۔ صرف اسی جدول میں درج حروف شمار کیے جائیں گے۔"
                else
                    "اردو اور فارسی کے اضافی حروف کو ان کے روایتی بنیادی حرف کی عددی قدر دی گئی ہے۔ مختلف روایات میں اختلاف ممکن ہے۔",
                fontSize = 12.sp, color = Color.Gray
            )
        }

        Panel("اسی ابجدی حساب سے نقش منتخب کریں") {
            Text("مطلوبہ نقش پر دبائیں؛ نقش اسی اسکرین پر ظاہر ہوگا۔", color = Ink, fontSize = 13.sp)
            naqshTypes.chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    pair.forEach { (n, label) ->
                        Button(
                            onClick = {
                                selectedOrder = n
                                generatedLabel = label
                                generatedGrid = magicSquare(n)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedOrder == n) Green else Color(0xFFEAF4EE),
                                contentColor = if (selectedOrder == n) Color.White else Green
                            )
                        ) { Text(label, fontSize = 12.sp) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (generatedGrid != null) {
                Divider(color = Color(0xFFD8E8DE))
                Text("$generatedLabel — ${selectedOrder} × ${selectedOrder}", color = Green, fontWeight = FontWeight.Bold)
                Text(
                    "معیاری نقش کا ہر قطار، ستون اور قطر کا مجموعہ: ${selectedOrder * (selectedOrder * selectedOrder + 1) / 2}",
                    color = Ink, fontSize = 12.sp
                )
                Text(
                    "ابجد کا حاصل کردہ عدد $total الگ محفوظ رہے گا؛ یہ معیاری نقش 1 سے ${selectedOrder * selectedOrder} تک کے اعداد سے تیار ہوا ہے۔",
                    color = Color.Gray, fontSize = 11.sp
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = PaleGreen)
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(selectedOrder),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 330.dp).padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        items(generatedGrid!!.flatten()) { value ->
                            Box(
                                Modifier.aspectRatio(1f).background(Color.White, RoundedCornerShape(5.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    value.toString(), color = Ink,
                                    fontSize = if (selectedOrder > 9) 9.sp else 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val saved = saveNaqshPng(context, generatedGrid!!)
                            Toast.makeText(context, if (saved != null) "نقش تصویر میں محفوظ ہوگیا" else "تصویر محفوظ نہیں ہوسکی", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Green)
                    ) { Text("PNG محفوظ کریں", fontSize = 12.sp) }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val saved = saveNaqshPdf(context, generatedGrid!!)
                            Toast.makeText(context, if (saved != null) "PDF ڈاؤن لوڈز میں محفوظ ہوگئی" else "PDF محفوظ نہیں ہوسکی", Toast.LENGTH_SHORT).show()
                        }
                    ) { Text("PDF محفوظ کریں", fontSize = 12.sp) }
                }
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        saveNaqshHistory(context, selectedOrder, generatedGrid!!)
                        Toast.makeText(context, "نقش محفوظات میں شامل ہوگیا", Toast.LENGTH_SHORT).show()
                    }
                ) { Text("محفوظات میں رکھیں") }
            }
        }

        Panel("حساب کی وضاحت") {
            Text("یہ جدول روایتی ابجدِ کبیر کے معروف نظام پر مبنی ہے۔ یہ اعداد تاریخی/روایتی حساب ہیں، سائنسی پیش گوئی یا طبی تشخیص نہیں۔")
        }
    }
}

fun oddMagicSquare(n: Int): List<List<Int>> {
    val a = Array(n) { IntArray(n) }
    var r = 0
    var c = n / 2
    for (v in 1..(n * n)) {
        a[r][c] = v
        val nr = (r - 1 + n) % n
        val nc = (c + 1) % n
        if (a[nr][nc] != 0) r = (r + 1) % n
        else { r = nr; c = nc }
    }
    return a.map { it.toList() }
}

fun doublyEvenMagicSquare(n: Int): List<List<Int>> {
    val max = n * n + 1
    return List(n) { r ->
        List(n) { c ->
            val v = r * n + c + 1
            if ((r % 4 == c % 4) || ((r % 4) + (c % 4) == 3)) max - v else v
        }
    }
}

/** Generates a normal magic square for odd, doubly-even, and singly-even orders. */
fun magicSquare(n: Int): List<List<Int>> {
    require(n >= 3)
    if (n % 2 == 1) return oddMagicSquare(n)
    if (n % 4 == 0) return doublyEvenMagicSquare(n)
    val half = n / 2
    val k = (n - 2) / 4
    val block = half * half
    val base = oddMagicSquare(half)
    val result = Array(n) { IntArray(n) }
    for (r in 0 until half) for (c in 0 until half) {
        val v = base[r][c]
        result[r][c] = v
        result[r][c + half] = v + 2 * block
        result[r + half][c] = v + 3 * block
        result[r + half][c + half] = v + block
    }
    for (r in 0 until half) {
        for (c in 0 until k) {
            val t = result[r][c]; result[r][c] = result[r + half][c]; result[r + half][c] = t
        }
        for (c in (half - k + 1) until half) {
            val t = result[r][c + half]; result[r][c + half] = result[r + half][c + half]; result[r + half][c + half] = t
        }
    }
    val first = result[k][0]; result[k][0] = result[k + half][0]; result[k + half][0] = first
    val middle = result[k][k]; result[k][k] = result[k + half][k]; result[k + half][k] = middle
    return result.map { it.toList() }
}


private data class SavedNaqsh(val order: Int, val grid: List<List<Int>>)

private fun loadNaqshHistory(context: android.content.Context): List<SavedNaqsh> {
    val raw = context.getSharedPreferences("anja_naqoosh", android.content.Context.MODE_PRIVATE)
        .getString("history", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val obj = array.optJSONObject(i) ?: return@mapNotNull null
            val n = obj.optInt("order", 0)
            val rows = obj.optJSONArray("grid") ?: return@mapNotNull null
            if (n !in 3..15 || rows.length() != n) return@mapNotNull null
            val values = (0 until rows.length()).map { r ->
                val row = rows.optJSONArray(r) ?: JSONArray()
                (0 until row.length()).map { c -> row.optInt(c) }
            }
            if (values.any { it.size != n }) null else SavedNaqsh(n, values)
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveNaqshHistory(context: android.content.Context, order: Int, grid: List<List<Int>>) {
    val prefs = context.getSharedPreferences("anja_naqoosh", android.content.Context.MODE_PRIVATE)
    val existing = JSONArray(prefs.getString("history", "[]") ?: "[]")
    val next = JSONArray()
    next.put(JSONObject().put("order", order).put("grid", JSONArray().also { rows ->
        grid.forEach { row -> rows.put(JSONArray(row)) }
    }))
    for (i in 0 until minOf(existing.length(), 19)) next.put(existing.getJSONObject(i))
    prefs.edit().putString("history", next.toString()).apply()
}

private fun deleteNaqshHistory(context: android.content.Context, index: Int) {
    val old = JSONArray(context.getSharedPreferences("anja_naqoosh", android.content.Context.MODE_PRIVATE)
        .getString("history", "[]") ?: "[]")
    val next = JSONArray()
    for (i in 0 until old.length()) if (i != index) next.put(old.getJSONObject(i))
    context.getSharedPreferences("anja_naqoosh", android.content.Context.MODE_PRIVATE)
        .edit().putString("history", next.toString()).apply()
}

@Composable
fun NaqshScreen(modifier: Modifier = Modifier) {
    var sizeText by remember { mutableStateOf("3") }
    var order by remember { mutableIntStateOf(3) }
    var error by remember { mutableStateOf("") }
    var grid by remember { mutableStateOf(magicSquare(3)) }
    val context = androidx.compose.ui.platform.LocalContext.current
    var historyOpen by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(loadNaqshHistory(context)) }
    Column(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel("اعدادی نقش ساز") {
            Text("3 سے 15 تک کسی بھی سائز کا عددی مربع منتخب کریں۔")
            OutlinedTextField(
                value = sizeText,
                onValueChange = { sizeText = it.filter(Char::isDigit).take(2) },
                label = { Text("خانے: 3 تا 15") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val n = sizeText.toIntOrNull()
                    if (n == null || n !in 3..15) {
                        error = "براہ کرم 3 سے 15 کے درمیان سائز منتخب کریں۔"
                    } else {
                        order = n
                        grid = magicSquare(n)
                        error = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) { Text("نقش تیار کریں") }
            if (error.isNotEmpty()) Text(error, color = Color(0xFFB3261E))
            Text("ترتیب: ${order} × ${order}  |  ہر قطار، ستون اور قطر کا مجموعہ: ${order * (order * order + 1) / 2}",
                color = Green, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(modifier = Modifier.weight(1f), onClick = {
                    val saved = saveNaqshPng(context, grid)
                    Toast.makeText(context, if (saved != null) "نقش تصویر میں محفوظ ہوگیا" else "تصویر محفوظ نہیں ہوسکی", Toast.LENGTH_SHORT).show()
                }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("PNG محفوظ کریں") }
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    val saved = saveNaqshPdf(context, grid)
                    Toast.makeText(context, if (saved != null) "PDF ڈاؤن لوڈز میں محفوظ ہوگئی" else "PDF محفوظ نہیں ہوسکی", Toast.LENGTH_SHORT).show()
                }) { Text("PDF محفوظ کریں") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    saveNaqshHistory(context, order, grid)
                    history = loadNaqshHistory(context)
                    Toast.makeText(context, "نقش محفوظات میں شامل ہوگیا", Toast.LENGTH_SHORT).show()
                }) { Text("محفوظات میں رکھیں") }
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    history = loadNaqshHistory(context)
                    historyOpen = true
                }) { Text("محفوظ نقش دیکھیں") }
            }
        }
        if (historyOpen) {
            AlertDialog(
                onDismissRequest = { historyOpen = false },
                title = { Text("محفوظ شدہ نقوش") },
                text = {
                    if (history.isEmpty()) Text("ابھی کوئی نقش محفوظ نہیں۔")
                    else Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        history.forEachIndexed { index, item ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${item.order} × ${item.order}", modifier = Modifier.weight(1f))
                                TextButton(onClick = {
                                    order = item.order
                                    sizeText = item.order.toString()
                                    grid = item.grid
                                    historyOpen = false
                                }) { Text("کھولیں") }
                                TextButton(onClick = {
                                    deleteNaqshHistory(context, index)
                                    history = loadNaqshHistory(context)
                                }) { Text("حذف") }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { historyOpen = false }) { Text("بند کریں") } }
            )
        }
        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            colors = CardDefaults.cardColors(containerColor = PaleGreen)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(order),
                modifier = Modifier.fillMaxSize().padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(grid.flatten()) { value ->
                    Box(
                        Modifier.aspectRatio(1f).background(Color.White, RoundedCornerShape(5.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(value.toString(), color = Ink, fontSize = if (order > 9) 10.sp else 14.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel("ایپ کے بارے میں") {
            Text("ANJA NAQOOSH MAKER")
            Text("ادارہ انجاء ہیلنگ سینٹر")
            Text("یہ ورژن عربی، اردو اور فارسی ابجد کے منتخب جدول اور 3 تا 15 کے عددی مربعات تیار کرتا ہے۔")
            Text("موجودہ سہولتیں: ابجدِ کبیر کا بنیادی حساب، عددی مربع، PNG تصویر اور PDF محفوظ کرنا۔")
            Text("آئندہ مراحل: مزید ابجدی جدول، شاگرد پروفائل اور آن لائن ہم آہنگی۔")
        }
        Panel("ذمہ دارانہ استعمال") {
            Text("ایپ کے حسابات اور نقش تعلیمی و روایتی معلومات کے لیے ہیں۔ انہیں طبی علاج، مالی فیصلوں یا یقینی روحانی نتائج کا متبادل نہ سمجھیں۔")
        }
    }
}
