package com.anja.naqoomaker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF176B45)
private val PaleGreen = Color(0xFFEAF4EE)
private val Ink = Color(0xFF18372A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnjaApp() }
    }
}

@Composable
fun AnjaApp() {
    var page by remember { mutableStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = Color(0xFF4D8B68),
            background = Color(0xFFF8FBF8),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Color(0xFFF8FBF8),
                topBar = {
                    Column(
                        Modifier.fillMaxWidth().background(Green).padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("ANJA NAQOOSH MAKER", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("ادارہ انجاء ہیلنگ سینٹر", color = Color.White, fontSize = 14.sp)
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(selected = page == 0, onClick = { page = 0 },
                            icon = { Text("ا ب") }, label = { Text("ابجد حساب") })
                        NavigationBarItem(selected = page == 1, onClick = { page = 1 },
                            icon = { Text("▦") }, label = { Text("نقش ساز") })
                        NavigationBarItem(selected = page == 2, onClick = { page = 2 },
                            icon = { Text("؟") }, label = { Text("تعارف") })
                    }
                }
            ) { padding ->
                when (page) {
                    0 -> AbjadScreen(Modifier.padding(padding))
                    1 -> NaqshScreen(Modifier.padding(padding))
                    else -> AboutScreen(Modifier.padding(padding))
                }
            }
        }
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFD8E8DE)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

private val abjadValues = mapOf(
    'ا' to 1, 'آ' to 1, 'ء' to 1, 'ب' to 2, 'ج' to 3, 'د' to 4,
    'ہ' to 5, 'ه' to 5, 'و' to 6, 'ز' to 7, 'ح' to 8, 'ط' to 9,
    'ی' to 10, 'ي' to 10, 'ک' to 20, 'ك' to 20, 'ل' to 30, 'م' to 40,
    'ن' to 50, 'س' to 60, 'ع' to 70, 'ف' to 80, 'ص' to 90,
    'ق' to 100, 'ر' to 200, 'ش' to 300, 'ت' to 400, 'ث' to 500,
    'خ' to 600, 'ذ' to 700, 'ض' to 800, 'ظ' to 900, 'غ' to 1000
)

@Composable
fun AbjadScreen(modifier: Modifier = Modifier) {
    var input by remember { mutableStateOf("") }
    val total = input.sumOf { abjadValues[it] ?: 0 }
    val breakdown = input.filter { abjadValues.containsKey(it) }
        .map { "$it = ${abjadValues[it]}" }
    Column(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Panel("ابجد کبیر کا حساب") {
            Text("اپنا نام یا عبارت درج کریں۔", color = Ink)
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("مثلاً: محمد") },
                minLines = 2
            )
            Text("کل عدد: $total", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (breakdown.isNotEmpty()) Text(breakdown.joinToString("   "))
            Text("یہ ابتدائی ابجدِ کبیر جدول ہے؛ غیر شامل حروف صفر شمار ہوں گے۔", fontSize = 12.sp, color = Color.Gray)
        }
        Panel("اہم وضاحت") {
            Text("یہ حساب حروف کی روایتی عددی قدروں پر مبنی ہے۔ مختلف مکاتب یا جدولوں میں بعض حروف کی قدر مختلف ہو سکتی ہے۔")
        }
    }
}

fun oddMagicSquare(n: Int): List<List<Int>> {
    val a = Array(n) { IntArray(n) }
    var r = 0
    var c = n / 2
    for (v in 1..(n * n)) {
        a[r][c] = v
        val nr = (r - 1 + n) % n
        val nc = (c + 1) % n
        if (a[nr][nc] != 0) r = (r + 1) % n
        else { r = nr; c = nc }
    }
    return a.map { it.toList() }
}

fun doublyEvenMagicSquare(n: Int): List<List<Int>> {
    val max = n * n + 1
    return List(n) { r ->
        List(n) { c ->
            val v = r * n + c + 1
            if ((r % 4 == c % 4) || ((r % 4) + (c % 4) == 3)) max - v else v
        }
    }
}

@Composable
fun NaqshScreen(modifier: Modifier = Modifier) {
    var sizeText by remember { mutableStateOf("3") }
    var order by remember { mutableIntStateOf(3) }
    var error by remember { mutableStateOf("") }
    var grid by remember { mutableStateOf(oddMagicSquare(3)) }
    Column(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel("اعدادی نقش ساز") {
            Text("نقش کے خانے منتخب کریں (ابتدائی ورژن میں 3 تا 15 کے منتخب سائز)۔")
            OutlinedTextField(
                value = sizeText,
                onValueChange = { sizeText = it.filter(Char::isDigit).take(2) },
                label = { Text("خانے: 3، 4، 5، 8، 12 وغیرہ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val n = sizeText.toIntOrNull()
                    if (n == null || n !in 3..15 || n == 6 || n == 10 || n == 14) {
                        error = "اس ورژن میں 3 تا 15 میں طاق سائز اور 4، 8، 12 دستیاب ہیں۔"
                    } else {
                        order = n
                        grid = if (n % 2 == 1) oddMagicSquare(n) else doublyEvenMagicSquare(n)
                        error = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) { Text("نقش تیار کریں") }
            if (error.isNotEmpty()) Text(error, color = Color(0xFFB3261E))
            Text("ترتیب: ${order} × ${order}  |  ہر قطار، ستون اور قطر کا مجموعہ: ${order * (order * order + 1) / 2}",
                color = Green, fontWeight = FontWeight.SemiBold)
        }
        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            colors = CardDefaults.cardColors(containerColor = PaleGreen)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(order),
                modifier = Modifier.fillMaxSize().padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(grid.flatten()) { value ->
                    Box(
                        Modifier.aspectRatio(1f).background(Color.White, RoundedCornerShape(5.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(value.toString(), color = Ink, fontSize = if (order > 9) 10.sp else 14.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel("ایپ کے بارے میں") {
            Text("ANJA NAQOOSH MAKER")
            Text("ادارہ انجاء ہیلنگ سینٹر")
            Text("یہ ابتدائی ورژن ابجدِ کبیر کے بنیادی حساب اور منتخب سائز کے عددی مربعات تیار کرتا ہے۔")
            Text("اگلے مراحل: نقش محفوظ کرنا، تصویر/PDF برآمد، مزید ابجدی جدول، شاگرد پروفائل اور آن لائن ہم آہنگی۔")
        }
        Panel("ذمہ دارانہ استعمال") {
            Text("ایپ کے حسابات اور نقش تعلیمی و روایتی معلومات کے لیے ہیں۔ انہیں طبی علاج، مالی فیصلوں یا یقینی روحانی نتائج کا متبادل نہ سمجھیں۔")
        }
    }
}
