# ANJA NAQOOSH MAKER — ورژن 0.5.0

## موجودہ خصوصیات
- اردو RTL انٹرفیس، سفید اور سبز تھیم۔
- ابجدِ عربی، اردو اور فارسی کے منتخب روایتی جدول۔
- 3 تا 15 تک عددی نارمل جادوئی مربع (Magic Square)۔
- قطار، ستون اور دونوں قطروں کے یکساں مجموعے۔
- PNG تصویر اور PDF برآمد۔
- فون میں مقامی محفوظات: نقش محفوظ کریں، دوبارہ کھولیں اور حذف کریں۔
- بنیادی حساب آف لائن چلتا ہے؛ انٹرنیٹ لازمی نہیں۔

## ضروری وضاحت
اردو/فارسی اضافی حروف کی قدریں بعض روایات میں مختلف ہیں؛ ایپ میں دی گئی قدریں منتخب روایتی mapping ہیں، قطعی یا واحد مستند جدول نہیں۔ یہ ایپ طبی تشخیص، علاج یا مستقبل کی یقینی پیش گوئی نہیں کرتی۔

## Android Studio سے APK بنائیں
1. ZIP extract کریں۔
2. Android Studio میں `ANJA_NAQOOSH_MAKER` فولڈر کھولیں۔
3. Gradle Sync مکمل کریں (JDK 17، Android SDK 35 درکار)۔
4. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
5. APK عام طور پر `app/build/outputs/apk/debug/app-debug.apk` میں ملے گی۔

یہ سورس پروجیکٹ ہے؛ یہاں APK کمپائل یا حقیقی فون پر ٹیسٹ نہیں کی گئی۔

## GitHub سے موبائل APK بنانا (کمپیوٹر کے بغیر)
اس پروجیکٹ میں GitHub Actions workflow شامل ہے:
1. اس ZIP کو extract کرکے تمام فائلیں اپنے GitHub repository کے root میں upload کریں۔
2. GitHub repository میں **Actions** ٹیب کھولیں۔
3. `Build Android APK` workflow چلائیں یا `main` پر push کے بعد مکمل ہونے دیں۔
4. کامیاب run کھولیں؛ نیچے **Artifacts** میں `ANJA-NAQOOSH-MAKER-debug-apk` ڈاؤن لوڈ کریں۔
5. ZIP کھول کر `app-debug.apk` اپنے Android فون میں انسٹال کریں۔ پہلی بار Android کی اجازت مانگی جا سکتی ہے۔

اگر Actions میں build failed آئے تو سرخ error log کا screenshot یا متن بھیجیں؛ اسی error کو درست کیا جائے گا۔
