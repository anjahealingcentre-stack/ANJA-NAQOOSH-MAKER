def odd(n):
    a=[[0]*n for _ in range(n)]; r=0; c=n//2
    for v in range(1,n*n+1):
        a[r][c]=v; nr=(r-1)%n; nc=(c+1)%n
        if a[nr][nc]: r=(r+1)%n
        else: r,c=nr,nc
    return a

def even4(n):
    return [[n*n+1-(r*n+c+1) if r%4==c%4 or (r%4+c%4)==3 else r*n+c+1 for c in range(n)] for r in range(n)]

def square(n):
    if n%2: return odd(n)
    if n%4==0: return even4(n)
    h=n//2; k=(n-2)//4; q=h*h; b=odd(h); a=[[0]*n for _ in range(n)]
    for r in range(h):
        for c in range(h):
            v=b[r][c]; a[r][c]=v; a[r][c+h]=v+2*q; a[r+h][c]=v+3*q; a[r+h][c+h]=v+q
    for r in range(h):
        for c in range(k): a[r][c],a[r+h][c]=a[r+h][c],a[r][c]
        for c in range(h-k+1,h): a[r][c+h],a[r+h][c+h]=a[r+h][c+h],a[r][c+h]
    a[k][0],a[k+h][0]=a[k+h][0],a[k][0]
    a[k][k],a[k+h][k]=a[k+h][k],a[k][k]
    return a

for n in range(3,16):
    a=square(n); target=n*(n*n+1)//2
    assert sorted(sum(a,[]))==list(range(1,n*n+1)), n
    assert all(sum(row)==target for row in a), n
    assert all(sum(a[r][c] for r in range(n))==target for c in range(n)), n
    assert sum(a[i][i] for i in range(n))==target, n
    assert sum(a[i][n-1-i] for i in range(n))==target, n
    print(f'{n}x{n}: OK; constant={target}')
