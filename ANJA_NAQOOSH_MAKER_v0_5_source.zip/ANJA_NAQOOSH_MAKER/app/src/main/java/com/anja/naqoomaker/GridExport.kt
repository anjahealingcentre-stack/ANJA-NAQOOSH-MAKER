package com.anja.naqoomaker

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.net.Uri

/** Exports a generated numeric square to Pictures/AnjaNaqoosh. */
fun saveNaqshPng(context: Context, grid: List<List<Int>>): Uri? {
    if (grid.isEmpty() || grid.any { it.size != grid.size }) return null
    val n = grid.size; val cell = 180; val margin = 32
    val bitmap = Bitmap.createBitmap(n * cell + margin * 2, n * cell + margin * 2, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE)
    val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(23,107,69); strokeWidth = 3f; style = Paint.Style.STROKE }
    val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(24,55,42); textSize = if (n > 9) 25f else 34f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    for (r in 0 until n) for (c in 0 until n) {
        val x = margin + c * cell; val y = margin + r * cell
        canvas.drawRect(x.toFloat(), y.toFloat(), (x+cell).toFloat(), (y+cell).toFloat(), border)
        canvas.drawText(grid[r][c].toString(), x + cell/2f, y + cell/2f + text.textSize/3f, text)
    }
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "ANJA_NAQSH_${n}x$n.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AnjaNaqoosh")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    if (uri != null) context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle(); return uri
}

/** Exports a generated numeric square to Downloads/AnjaNaqoosh. */
fun saveNaqshPdf(context: Context, grid: List<List<Int>>): Uri? {
    if (grid.isEmpty() || grid.any { it.size != grid.size }) return null
    val n = grid.size; val doc = PdfDocument(); val pageSize = 595
    val page = doc.startPage(PdfDocument.PageInfo.Builder(pageSize, pageSize, 1).create())
    val canvas = page.canvas
    val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(23,107,69); strokeWidth = 1.5f; style = Paint.Style.STROKE }
    val heading = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(23,107,69); textSize = 21f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    val number = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(24,55,42); textSize = if (n > 9) 10f else 15f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    canvas.drawText("ANJA NAQOOSH MAKER - ${n} x $n", pageSize/2f, 42f, heading)
    val side = 500f/n; val left = (pageSize-500f)/2f; val top = 65f
    for (r in 0 until n) for (c in 0 until n) {
        val x = left+c*side; val y = top+r*side
        canvas.drawRect(x,y,x+side,y+side,line)
        canvas.drawText(grid[r][c].toString(),x+side/2,y+side/2+number.textSize/3,number)
    }
    doc.finishPage(page)
    val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME,"ANJA_NAQSH_${n}x$n.pdf")
        put(MediaStore.Downloads.MIME_TYPE,"application/pdf")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/AnjaNaqoosh")
    }
    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
    if (uri != null) context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
    doc.close(); return uri
}
